targetScope = 'resourceGroup'

@description('Globally unique Azure App Service name.')
param appName string

@description('Microsoft Entra application (client) ID used by App Service Authentication.')
param entraAuthenticationClientId string

@description('Deployment location.')
param location string = resourceGroup().location

@description('Linux App Service plan SKU.')
@allowed(['B1', 'B2', 'B3', 'P0v3', 'P1v3', 'P2v3'])
param skuName string = 'B1'

@secure()
@description('Authorized OneDrive/SharePoint folder sharing URL.')
param oneDriveFolderShareUrl string

@secure()
@description('Protected Copilot Studio token endpoint. Leave empty only when DIRECT_LINE_SECRET is supplied separately through Key Vault.')
param copilotTokenEndpoint string = ''

param tags object = {
  workload: 'Enzyme Enterprise Copilot'
  version: '2.3.0'
  managedBy: 'Bicep'
}

var tenantId = 'cd11d182-105e-4331-a55d-6e2db544ee3f'
var appSettings = {
  NODE_ENV: 'production'
  PORT: '8080'
  REQUIRE_EASY_AUTH: 'true'
  EXPECTED_ENTRA_TENANT_ID: tenantId
  ENTRA_TENANT_ID: tenantId
  POWER_PLATFORM_ENVIRONMENT_ID: 'Default-cd11d182-105e-4331-a55d-6e2db544ee3f'
  DATAVERSE_URL: 'https://orgd66b8caf.crm4.dynamics.com/'
  COPILOT_AGENT_ID: '91ac31d0-af7f-4a75-b82c-af78ceb3e6b3'
  COPILOT_AGENT_SCHEMA_NAME: 'cr1c6_enzymeenterprisecopilot_zgMsug'
  COPILOT_AGENT_NAME: 'Enzyme Enterprise Copilot'
  GRAPH_BASE_URL: 'https://graph.microsoft.com/v1.0'
  LOGIN_BASE_URL: 'https://login.microsoftonline.com'
  DIRECT_LINE_BASE_URL: 'https://directline.botframework.com/v3/directline'
  GRAPH_ALLOWED_HOSTS: 'graph.microsoft.com'
  LOGIN_ALLOWED_HOSTS: 'login.microsoftonline.com'
  DIRECT_LINE_ALLOWED_HOSTS: 'directline.botframework.com'
  COPILOT_ALLOWED_HOSTS: '*.environment.api.powerplatform.com,*.api.powerplatform.com,*.botframework.com'
  ONEDRIVE_ALLOWED_HOSTS: '*.sharepoint.com,*.my.sharepoint.com,1drv.ms'
  UPSTREAM_TIMEOUT_MS: '15000'
  MAX_UPSTREAM_RESPONSE_BYTES: '16777216'
  MAX_AUDIT_FILE_BYTES: '67108864'
  ONEDRIVE_FOLDER_SHARE_URL: oneDriveFolderShareUrl
  COPILOT_TOKEN_ENDPOINT: copilotTokenEndpoint
  WEBSITE_NODE_DEFAULT_VERSION: '~20'
  SCM_DO_BUILD_DURING_DEPLOYMENT: 'false'
}

resource plan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: '${appName}-plan'
  location: location
  tags: tags
  sku: {
    name: skuName
  }
  kind: 'linux'
  properties: {
    reserved: true
  }
}

resource app 'Microsoft.Web/sites@2023-12-01' = {
  name: appName
  location: location
  tags: tags
  kind: 'app,linux'
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    serverFarmId: plan.id
    httpsOnly: true
    publicNetworkAccess: 'Enabled'
    siteConfig: {
      linuxFxVersion: 'NODE|20-lts'
      appCommandLine: 'node server.js'
      alwaysOn: true
      ftpsState: 'Disabled'
      minTlsVersion: '1.2'
      http20Enabled: true
      healthCheckPath: '/api/health'
      appSettings: [for setting in items(appSettings): {
        name: setting.key
        value: string(setting.value)
      }]
    }
  }
}

resource auth 'Microsoft.Web/sites/config@2023-12-01' = {
  parent: app
  name: 'authsettingsV2'
  properties: {
    platform: {
      enabled: true
      runtimeVersion: '~1'
    }
    globalValidation: {
      requireAuthentication: true
      unauthenticatedClientAction: 'Return401'
      redirectToProvider: 'azureactivedirectory'
    }
    identityProviders: {
      azureActiveDirectory: {
        enabled: true
        registration: {
          clientId: entraAuthenticationClientId
          openIdIssuer: 'https://login.microsoftonline.com/${tenantId}/v2.0'
        }
        validation: {
          allowedAudiences: [
            'https://${app.properties.defaultHostName}'
          ]
        }
      }
    }
    login: {
      tokenStore: {
        enabled: true
      }
    }
    httpSettings: {
      requireHttps: true
      routes: {
        apiPrefix: '/.auth'
      }
    }
  }
}

output webAppName string = app.name
output defaultHostName string = app.properties.defaultHostName
output managedIdentityPrincipalId string = app.identity.principalId
output readinessUrl string = 'https://${app.properties.defaultHostName}/api/readiness'
