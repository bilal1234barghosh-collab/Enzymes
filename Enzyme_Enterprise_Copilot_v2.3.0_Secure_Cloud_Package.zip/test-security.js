'use strict';
const assert = require('assert');
const fs = require('fs');
const { spawn } = require('child_process');
function run(env, script='server.js') { return new Promise(resolve => { const p = spawn(process.execPath, [script], { cwd: __dirname, env: { ...process.env, DIRECT_LINE_SECRET:'', COPILOT_TOKEN_ENDPOINT:'', IDENTITY_ENDPOINT:'', IDENTITY_HEADER:'', MSI_ENDPOINT:'', MSI_SECRET:'', ENTRA_CLIENT_ID:'', ENTRA_CLIENT_SECRET:'', ...env }, stdio: ['ignore','pipe','pipe'] }); let out=''; p.stdout.on('data',d=>out+=d); p.stderr.on('data',d=>out+=d); if(script==='server.js')setTimeout(()=>{ if (!p.killed) p.kill('SIGTERM'); },250); p.on('exit',code=>resolve({code,out})); }); }
function parsed(x){ return JSON.parse(x.out.slice(x.out.indexOf('{'))); }
function check(out,name){ return parsed(out).checks.find(v=>v.name===name); }
(async()=>{
  let x=await run({NODE_ENV:'production',COPILOT_TOKEN_ENDPOINT:'http://127.0.0.1/token'},'preflight.js'); assert.equal(check(x,'COPILOT_BROKER').status,'BLOCKED'); assert(check(x,'COPILOT_BROKER').value.includes('HTTPS is required'));
  x=await run({NODE_ENV:'production',COPILOT_TOKEN_ENDPOINT:'https://evil.example/token'},'preflight.js'); assert(check(x,'COPILOT_BROKER').value.includes('non-allow-listed endpoint'));
  x=await run({NODE_ENV:'production',ONEDRIVE_FOLDER_SHARE_URL:'https://evil.example/folder'},'preflight.js'); assert(check(x,'ONEDRIVE_FOLDER_SHARE_URL').value.includes('non-allow-listed endpoint'));
  x=await run({NODE_ENV:'production',IDENTITY_ENDPOINT:'http://127.0.0.1:41741/msi/token',IDENTITY_HEADER:'platform-value'},'preflight.js'); assert(check(x,'GRAPH_AUTH').value.startsWith('MANAGED_IDENTITY:'));
  x=await run({NODE_ENV:'production',MSI_ENDPOINT:'http://169.254.169.254/metadata/identity/oauth2/token',MSI_SECRET:'platform-value'},'preflight.js'); assert(check(x,'GRAPH_AUTH').value.startsWith('MANAGED_IDENTITY:'));
  x=await run({NODE_ENV:'production',IDENTITY_ENDPOINT:'http://evil.example/msi/token',IDENTITY_HEADER:'platform-value'},'preflight.js'); assert(check(x,'GRAPH_AUTH').value.startsWith('INVALID:'));
  x=await run({NODE_ENV:'production',IDENTITY_ENDPOINT:'http://127.0.0.1:41741/wrong',IDENTITY_HEADER:'platform-value'},'preflight.js'); assert(check(x,'GRAPH_AUTH').value.startsWith('INVALID:'));
  x=await run({NODE_ENV:'production',IDENTITY_ENDPOINT:'http://127.0.0.1:41741/msi/token'},'preflight.js'); assert(check(x,'GRAPH_AUTH').value.startsWith('INCOMPLETE:'));
  x=await run({NODE_ENV:'production',MAX_UPSTREAM_RESPONSE_BYTES:'1000'},'preflight.js'); assert.equal(check(x,'MAX_UPSTREAM_RESPONSE_BYTES').status,'BLOCKED');
  x=await run({NODE_ENV:'production',MAX_UPSTREAM_RESPONSE_BYTES:'16777216',MAX_AUDIT_FILE_BYTES:'1048576'},'preflight.js'); assert.equal(check(x,'MAX_AUDIT_FILE_BYTES').status,'BLOCKED');
  x=await run({NODE_ENV:'production',GRAPH_BASE_URL:'https://evil.example/v1.0',PORT:'19095'}); assert.notEqual(x.code,0); assert(x.out.includes('GRAPH_BASE_URL'));
  const server=fs.readFileSync('server.js','utf8');
  assert(server.includes('Invalid Microsoft Graph relative path'));
  assert(server.includes('Audit event exceeds 64 KB')&&server.includes('AUDIT_FILE_LIMIT_REACHED'));
  assert(server.includes("'[REDACTED]'"));
  assert(server.includes('Strict-Transport-Security')&&server.includes('Cross-Origin-Resource-Policy'));
  assert(server.includes('/api/readiness')&&server.includes('UPSTREAM_RESPONSE_TOO_LARGE'));
  console.log(JSON.stringify({status:'PASS',checks:15,managedIdentityModern:true,managedIdentityLegacy:true,invalidIdentityBlocked:true,incompleteIdentityBlocked:true,hostAllowlists:true,ssrfGraphBlocked:true,auditControls:true,responseLimit:true,securityHeaders:true},null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
