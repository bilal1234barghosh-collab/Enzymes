'use strict';
const assert=require('assert');
const {spawn}=require('child_process');
const port=19093;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function principal(tenant){return Buffer.from(JSON.stringify({userId:'user-1',userDetails:'tester@example.invalid',claims:[{typ:'tid',val:tenant},{typ:'oid',val:'user-1'},{typ:'name',val:'Test User'}]})).toString('base64');}
async function call(path,opt={}){const r=await fetch(`http://127.0.0.1:${port}${path}`,opt),text=await r.text();let body;try{body=JSON.parse(text)}catch{body=text}return {r,body};}
(async()=>{let app;try{
 app=spawn(process.execPath,['server.js'],{cwd:__dirname,env:{...process.env,PORT:String(port),NODE_ENV:'production',REQUIRE_EASY_AUTH:'true'},stdio:['ignore','pipe','pipe']});
 for(let i=0;i<40;i++){try{const r=await fetch(`http://127.0.0.1:${port}/`);if(r.ok)break}catch{}await wait(50)}
 let x=await call('/api/config');assert.equal(x.r.status,401);
 x=await call('/api/config',{headers:{'x-ms-client-principal':principal('wrong-tenant')}});assert.equal(x.r.status,403);
 const auth={'x-ms-client-principal':principal('cd11d182-105e-4331-a55d-6e2db544ee3f')};
 x=await call('/api/config',{headers:auth});assert.equal(x.r.status,200);assert.equal(x.body.copilot.status,'Provisioned');
 x=await call('/api/cloud/audit',{method:'POST',headers:{...auth,'Content-Type':'application/json'},body:'{}'});assert.equal(x.r.status,403);
 x=await call('/api/cloud/audit',{method:'POST',headers:{...auth,'X-Enzyme-Request':'1','Origin':'https://evil.example','Content-Type':'application/json'},body:'{}'});assert.equal(x.r.status,403);
 x=await call('/api/cloud/audit',{method:'POST',headers:{...auth,'X-Enzyme-Request':'1','Origin':`https://127.0.0.1:${port}`,'X-Forwarded-Proto':'https','Content-Type':'application/json'},body:'{}'});assert.equal(x.r.status,503);
 console.log(JSON.stringify({status:'PASS',checks:6,unauthenticated:401,wrongTenant:403,csrfMissing:403,crossOrigin:403,sameOriginPassedGuard:true},null,2));
}finally{if(app){app.kill('SIGTERM');await wait(100)}}})().catch(e=>{console.error(e);process.exitCode=1});
