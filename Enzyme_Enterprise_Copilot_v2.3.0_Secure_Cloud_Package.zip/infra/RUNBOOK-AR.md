# دليل النشر والرجوع والأرشفة — v2.3.0

## 1) المتطلبات غير القابلة للتخمين
- Azure Subscription ID وResource Group واسم Web App فريد.
- Entra App Registration Client ID مخصص لـApp Service Authentication في المستأجر `cd11d182-105e-4331-a55d-6e2db544ee3f`.
- رابط مجلد OneDrive/SharePoint مصرح به.
- Copilot Token Endpoint محمي، أو Direct Line secret محفوظ كـKey Vault Reference.
- صلاحيات إدارية لمنح Managed Identity أقل صلاحية Microsoft Graph لازمة، ويفضل `Sites.Selected` مع تعيين الموقع المحدد.

## 2) التحقق قبل التغيير
1. احتفظ بحزمة v2.2.0 وبالحالة السحابية الحالية كخيار رجوع.
2. نفذ `node --check server.js preflight.js` ثم `node test-static.js && node test-integration.js && node test-auth.js && node test-security.js && node test-recovery.js`.
3. نفذ `NODE_ENV=production REQUIRE_EASY_AUTH=true node preflight.js`. لا تتابع إذا كانت نتيجة الإعداد غير مكتملة، باستثناء الموارد التي ستنشئها خطوة Bicep نفسها.
4. تحقق أن ملف ZIP لا يحتوي أسرارًا وأن بصماته تطابق `DEPLOYMENT-MANIFEST.json`.

## 3) النشر
1. انسخ `main.parameters.example.json` محليًا عند الحاجة، لكن لا تحفظ الأسرار فيه.
2. مرر القيم الحساسة في متغيرات بيئة جلسة آمنة وشغّل `infra/deploy.sh`.
3. القالب ينشئ Linux App Service، يفعّل HTTPS وSystem-Assigned Managed Identity وEasy Auth المرتبط بالمستأجر.
4. امنح Managed Identity صلاحية Graph بعد مراجعة المسؤول. لا توسع الصلاحيات أو قوائم المضيفين تلقائيًا.
5. لا تضبط `IDENTITY_ENDPOINT` أو`IDENTITY_HEADER` أو`MSI_ENDPOINT` أو`MSI_SECRET` يدويًا؛ Azure يحقنها.

## 4) التحقق بعد النشر
بالجلسة المؤسسية المصادق عليها:
- `GET /api/session`: المستأجر والهوية صحيحان.
- `GET /api/readiness`: HTTP `200` و`ready: true`.
- `GET /api/cloud/health`: `status: OK`.
- `GET /api/copilot/verify`: `verified: true` دون تسجيل الرمز.
- نفذ قراءة وكتابة حالة تجريبية غير حساسة، ثم تحقق من ETag، وHTTP `428` عند غياب `If-Match`، وHTTP `412` عند ETag قديم.
- تحقق من Backup وAudit اليومي ومن ظهور `X-Request-ID` في النجاح والخطأ.
- نفذ Regression Check للمحرك والواجهة والتقارير وAI والمعايرة والمزامنة والنسخ الاحتياطي والاستعادة.

## 5) الرجوع
1. أوقف تغييرات الحالة الجديدة، ولا تحذف سجلات Audit أوBackups.
2. أعد نشر حزمة v2.2.0 المعتمدة أوdeployment slot السابق.
3. استعد آخر حالة موثقة فقط بعد مقارنة checksum وETag وتسجيل سبب الاستعادة.
4. تحقق من `/api/session` و`/api/readiness` و`/api/cloud/health` والوظائف الأساسية.
5. سجل الإصدار السابق والجديد ووقت الرجوع والمنفذ والسبب.

## 6) أرشفة Audit اليومية
- الاسم: `EnzymeEnterprise-Audit-YYYY-MM-DD.ndjson`.
- الحد الافتراضي لكل ملف: `67108864` بايت. عند بلوغه يعيد النظام HTTP `507` و`AUDIT_FILE_LIMIT_REACHED` ولا يحذف الملف السابق.
- استخدم سياسة Retention/Archive مؤسسية معتمدة في SharePoint/OneDrive. انقل الملفات القديمة إلى مجلد أرشيف مقيد بدل حذفها.
- تحقق من checksum/الحجم ونجاح النسخة الأرشيفية قبل أي إجراء احتفاظ.
- لا تعدل السجلات السابقة ولا تدمجها بطريقة تفقد ترتيب الأحداث أوRequest ID.

## 7) معيار الإكمال
لا يُعد النشر إنتاجيًا قبل نجاح Production Preflight والتحقق الحي من Easy Auth وGraph read/write وETag وBackup وAudit وCopilot وCloud Sync، وتوثيق الصلاحيات والإصدارات والنتائج.
