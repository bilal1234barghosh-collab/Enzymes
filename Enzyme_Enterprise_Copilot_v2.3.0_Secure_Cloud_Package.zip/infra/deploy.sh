#!/usr/bin/env bash
set -euo pipefail

# Enzyme Enterprise Copilot v2.3.0 deployment helper.
# Required environment variables are intentionally not persisted by this script.
require_value() {
  local name="$1"
  local value="$2"
  if [[ -z "$value" ]]; then
    printf 'Missing required environment variable: %s\n' "$name" >&2
    exit 2
  fi
}
require_value AZURE_SUBSCRIPTION_ID "${AZURE_SUBSCRIPTION_ID:-}"
require_value AZURE_RESOURCE_GROUP "${AZURE_RESOURCE_GROUP:-}"
require_value AZURE_WEB_APP_NAME "${AZURE_WEB_APP_NAME:-}"
require_value ENTRA_AUTH_CLIENT_ID "${ENTRA_AUTH_CLIENT_ID:-}"
require_value ONEDRIVE_FOLDER_SHARE_URL "${ONEDRIVE_FOLDER_SHARE_URL:-}"
require_value COPILOT_TOKEN_ENDPOINT "${COPILOT_TOKEN_ENDPOINT:-}"
require_value PACKAGE_ZIP "${PACKAGE_ZIP:-}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOCATION="${AZURE_LOCATION:-}"
SKU_NAME="${AZURE_APP_SERVICE_SKU:-B1}"

az account set --subscription "$AZURE_SUBSCRIPTION_ID"
if ! az group show --name "$AZURE_RESOURCE_GROUP" >/dev/null 2>&1; then
  if [[ -z "$LOCATION" ]]; then
    echo 'AZURE_LOCATION is required when creating a new resource group.' >&2
    exit 2
  fi
  az group create --name "$AZURE_RESOURCE_GROUP" --location "$LOCATION" --tags workload='Enzyme Enterprise Copilot' version='2.3.0' >/dev/null
fi

DEPLOY_ARGS=(
  --resource-group "$AZURE_RESOURCE_GROUP"
  --template-file "$SCRIPT_DIR/main.bicep"
  --parameters appName="$AZURE_WEB_APP_NAME"
  --parameters entraAuthenticationClientId="$ENTRA_AUTH_CLIENT_ID"
  --parameters skuName="$SKU_NAME"
  --parameters oneDriveFolderShareUrl="$ONEDRIVE_FOLDER_SHARE_URL"
  --parameters copilotTokenEndpoint="$COPILOT_TOKEN_ENDPOINT"
)
if [[ -n "$LOCATION" ]]; then DEPLOY_ARGS+=(--parameters location="$LOCATION"); fi

az deployment group create "${DEPLOY_ARGS[@]}" --only-show-errors >/dev/null

# Package must be the application deployment ZIP, not the distribution archive containing reports.
az webapp deploy \
  --resource-group "$AZURE_RESOURCE_GROUP" \
  --name "$AZURE_WEB_APP_NAME" \
  --src-path "$PACKAGE_ZIP" \
  --type zip \
  --clean true \
  --restart true \
  --only-show-errors >/dev/null

HOST="$(az webapp show --resource-group "$AZURE_RESOURCE_GROUP" --name "$AZURE_WEB_APP_NAME" --query defaultHostName -o tsv)"
printf 'Deployment completed. Easy Auth should challenge unauthenticated requests at https://%s/api/readiness\n' "$HOST"
printf 'Managed Identity principal ID: '
az webapp identity show --resource-group "$AZURE_RESOURCE_GROUP" --name "$AZURE_WEB_APP_NAME" --query principalId -o tsv
printf '\nGrant the identity only the reviewed Microsoft Graph application permission and site-level Sites.Selected assignment before production verification.\n'
