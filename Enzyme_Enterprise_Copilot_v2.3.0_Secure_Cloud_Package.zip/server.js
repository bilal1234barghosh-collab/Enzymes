'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const net = require('net');
const { URL } = require('url');

const PORT = Number(process.env.PORT || 8080);
const IS_PRODUCTION = process.env.NODE_ENV === 'production';
const REQUIRE_AUTH = String(process.env.REQUIRE_EASY_AUTH || 'true').toLowerCase() === 'true' && IS_PRODUCTION;
const STATE_FILE = 'EnzymeEnterprise-State.json';
const PUBLIC = path.join(__dirname, 'public');
const MAX_BODY = 12 * 1024 * 1024;
const MAX_AUDIT_BYTES = 64 * 1024;
const parsedUpstreamLimit = Number(process.env.MAX_UPSTREAM_RESPONSE_BYTES || 16 * 1024 * 1024);
if (!Number.isSafeInteger(parsedUpstreamLimit) || parsedUpstreamLimit < 1024 || parsedUpstreamLimit > 128 * 1024 * 1024) throw new Error('MAX_UPSTREAM_RESPONSE_BYTES must be an integer between 1024 and 134217728');
const MAX_UPSTREAM_RESPONSE_BYTES = parsedUpstreamLimit;
const parsedAuditLimit = Number(process.env.MAX_AUDIT_FILE_BYTES || 64 * 1024 * 1024);
if (!Number.isSafeInteger(parsedAuditLimit) || parsedAuditLimit < MAX_UPSTREAM_RESPONSE_BYTES || parsedAuditLimit > 256 * 1024 * 1024) throw new Error('MAX_AUDIT_FILE_BYTES must be an integer between MAX_UPSTREAM_RESPONSE_BYTES and 268435456');
const MAX_AUDIT_FILE_BYTES = parsedAuditLimit;
const FETCH_TIMEOUT = Number(process.env.UPSTREAM_TIMEOUT_MS || 15000);
const APP_VERSION = '2.3.0';
const EXPECTED_TENANT_ID = process.env.EXPECTED_ENTRA_TENANT_ID || 'cd11d182-105e-4331-a55d-6e2db544ee3f';
const POWER_PLATFORM_ENVIRONMENT_ID = process.env.POWER_PLATFORM_ENVIRONMENT_ID || 'Default-cd11d182-105e-4331-a55d-6e2db544ee3f';
const DATAVERSE_URL = process.env.DATAVERSE_URL || 'https://orgd66b8caf.crm4.dynamics.com/';
const COPILOT_AGENT = Object.freeze({
  id: process.env.COPILOT_AGENT_ID || '91ac31d0-af7f-4a75-b82c-af78ceb3e6b3',
  schemaName: process.env.COPILOT_AGENT_SCHEMA_NAME || 'cr1c6_enzymeenterprisecopilot_zgMsug',
  name: process.env.COPILOT_AGENT_NAME || 'Enzyme Enterprise Copilot',
  state: 'Active', status: 'Provisioned', componentState: 'Published',
  publishedOn: '2026-09-19T00:14:30Z', authenticationMode: 'Integrated', authenticationTrigger: 'Always'
});

function isConfigured(value) {
  return Boolean(value && !/^\s*<[^>]+>\s*$/.test(value));
}
function privateIp(host) {
  if (host === 'localhost' || host.endsWith('.localhost')) return true;
  if (net.isIP(host) === 4) {
    const [a, b] = host.split('.').map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
  }
  if (net.isIP(host) === 6) return host === '::1' || host.startsWith('fc') || host.startsWith('fd') || host.startsWith('fe80:');
  return false;
}
function hostAllowed(host, allowed) {
  return allowed.some(entry => entry.startsWith('*.') ? host.endsWith(entry.slice(1)) && host !== entry.slice(2) : host === entry);
}
function validateUrl(setting, value, allowedHosts, allowTestHttp = false) {
  let url;
  try { url = new URL(value); } catch { throw Object.assign(new Error(`${setting} must be a valid absolute URL`), { statusCode: 503, code: 'INVALID_CONFIGURATION' }); }
  if (url.username || url.password || url.hash) throw Object.assign(new Error(`${setting} must not contain credentials or a fragment`), { statusCode: 503, code: 'INVALID_CONFIGURATION' });
  const testLocal = !IS_PRODUCTION && allowTestHttp && url.protocol === 'http:' && privateIp(url.hostname);
  if (url.protocol !== 'https:' && !testLocal) throw Object.assign(new Error(`${setting} must use HTTPS`), { statusCode: 503, code: 'INVALID_CONFIGURATION' });
  if (IS_PRODUCTION && (privateIp(url.hostname) || !hostAllowed(url.hostname.toLowerCase(), allowedHosts))) throw Object.assign(new Error(`${setting} host is not allow-listed`), { statusCode: 503, code: 'INVALID_CONFIGURATION' });
  return url.toString().replace(/\/$/, '');
}
function envHosts(name, defaults) {
  return String(process.env[name] || defaults.join(',')).split(',').map(x => x.trim().toLowerCase()).filter(Boolean);
}

const GRAPH_HOSTS = envHosts('GRAPH_ALLOWED_HOSTS', ['graph.microsoft.com']);
const LOGIN_HOSTS = envHosts('LOGIN_ALLOWED_HOSTS', ['login.microsoftonline.com']);
const DIRECT_LINE_HOSTS = envHosts('DIRECT_LINE_ALLOWED_HOSTS', ['directline.botframework.com']);
const COPILOT_HOSTS = envHosts('COPILOT_ALLOWED_HOSTS', ['*.environment.api.powerplatform.com', '*.api.powerplatform.com', '*.botframework.com']);
const ONEDRIVE_HOSTS = envHosts('ONEDRIVE_ALLOWED_HOSTS', ['*.sharepoint.com', '*.my.sharepoint.com', '1drv.ms']);
const GRAPH_BASE = validateUrl('GRAPH_BASE_URL', process.env.GRAPH_BASE_URL || 'https://graph.microsoft.com/v1.0', GRAPH_HOSTS, true);
const LOGIN_BASE = validateUrl('LOGIN_BASE_URL', process.env.LOGIN_BASE_URL || 'https://login.microsoftonline.com', LOGIN_HOSTS, true);
const DIRECT_LINE_BASE = validateUrl('DIRECT_LINE_BASE_URL', process.env.DIRECT_LINE_BASE_URL || 'https://directline.botframework.com/v3/directline', DIRECT_LINE_HOSTS, true);

let tokenCache = { token: null, expiresAt: 0 };
let folderCache = null;
let writeQueue = Promise.resolve();
const rateBuckets = new Map();
let lastRatePruneMinute = 0;

function requestId(req) { return String(req.headers['x-request-id'] || crypto.randomUUID()).replace(/[^A-Za-z0-9_.-]/g, '').slice(0, 80) || crypto.randomUUID(); }
function headers(extra = {}) { return { ...(IS_PRODUCTION ? { 'Strict-Transport-Security': 'max-age=31536000; includeSubDomains' } : {}), 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'Permissions-Policy': 'camera=(), microphone=(), geolocation=()', 'Cross-Origin-Opener-Policy': 'same-origin', 'Cross-Origin-Resource-Policy': 'same-origin', 'X-Permitted-Cross-Domain-Policies': 'none', 'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdnjs.cloudflare.com; font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com data:; img-src 'self' data: blob:; connect-src 'self' https://directline.botframework.com wss://directline.botframework.com; worker-src 'self' blob:; frame-src https://web.powerva.microsoft.com; object-src 'none'; base-uri 'self'; form-action 'self'", ...extra }; }
function send(res, status, body, extra = {}) { const data = body === null ? '' : JSON.stringify(body); res.writeHead(status, headers({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(data), ...extra })); res.end(data); }
function fail(res, status, message, id, extra = {}) { send(res, status, { error: message, requestId: id, ...extra }); }
function required(name) { const value = process.env[name]; if (!isConfigured(value)) throw Object.assign(new Error(`Missing server setting: ${name}`), { statusCode: 503, code: 'MISSING_CONFIGURATION' }); return value; }
function encodeShareUrl(value) { return 'u!' + Buffer.from(value, 'utf8').toString('base64url'); }
function enqueue(task) { const run = writeQueue.then(task, task); writeQueue = run.catch(() => {}); return run; }
function safeError(error) { const code = error?.code ? ` (${String(error.code).replace(/[^A-Z0-9_-]/gi, '').slice(0, 40)})` : ''; return `${String(error?.message || 'Unexpected server error').replace(/(client_secret|access_token|refresh_token|authorization|token)=([^&\s]+)/gi, '$1=[REDACTED]').slice(0, 420)}${code}`; }
function principal(req) { try { const raw = req.headers['x-ms-client-principal']; if (!raw) return null; const p = JSON.parse(Buffer.from(raw, 'base64').toString('utf8')); const claims = Array.isArray(p.claims) ? p.claims : []; const claim = (...types) => claims.find(c => types.includes(c.typ))?.val; return { id: p.userId || claim('http://schemas.microsoft.com/identity/claims/objectidentifier', 'oid') || null, tenantId: claim('http://schemas.microsoft.com/identity/claims/tenantid', 'tid') || null, name: p.userDetails || claim('name', 'preferred_username') || 'Authenticated user', roles: claims.filter(c => c.typ === 'roles' || c.typ === 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role').map(c => c.val) }; } catch { return null; } }
function actor(req) { const p = principal(req); return p ? { id: p.id, tenantId: p.tenantId, name: p.name, roles: p.roles } : { id: null, tenantId: null, name: 'local-test', roles: [] }; }
function mutationAllowed(req) { if (!REQUIRE_AUTH) return true; const marker = req.headers['x-enzyme-request'], origin = req.headers.origin; if (marker !== '1') return false; if (!origin) return true; try { const expected = `${req.headers['x-forwarded-proto'] || 'https'}://${req.headers.host}`; return new URL(origin).origin === new URL(expected).origin; } catch { return false; } }
function rateAllowed(req, limit = 120) { const p = principal(req), key = p?.id || req.socket.remoteAddress || 'unknown', minute = Math.floor(Date.now() / 60000); if (minute !== lastRatePruneMinute) { for (const [k, v] of rateBuckets) if (v.minute < minute - 1) rateBuckets.delete(k); lastRatePruneMinute = minute; } const id = `${key}:${minute}`, current = rateBuckets.get(id) || { minute, count: 0 }; current.count += 1; rateBuckets.set(id, current); return current.count <= limit; }
async function bodyJson(req) { let size = 0; const chunks = []; for await (const chunk of req) { size += chunk.length; if (size > MAX_BODY) throw Object.assign(new Error('Request payload exceeds 12 MB'), { statusCode: 413 }); chunks.push(chunk); } if (!size) return {}; try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw Object.assign(new Error('Invalid JSON payload'), { statusCode: 400 }); } }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
async function fetchSafe(url, opt = {}, attempt = 0) { const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT); try { const r = await fetch(url, { ...opt, signal: ctrl.signal }); if ((r.status === 429 || r.status >= 500) && attempt < 2) { try { await r.body?.cancel(); } catch {} const wait = Math.min(3000, Number(r.headers.get('retry-after') || 0) * 1000 || 250 * (2 ** attempt)); await sleep(wait); return fetchSafe(url, opt, attempt + 1); } return r; } catch (e) { if (attempt < 2 && e.name !== 'AbortError') { await sleep(250 * (2 ** attempt)); return fetchSafe(url, opt, attempt + 1); } throw Object.assign(new Error(e.name === 'AbortError' ? 'Upstream request timed out' : 'Upstream request failed'), { statusCode: 503, code: 'UPSTREAM_UNAVAILABLE' }); } finally { clearTimeout(timer); } }
async function responseBuffer(response, maxBytes = MAX_UPSTREAM_RESPONSE_BYTES) { const declared = Number(response.headers.get('content-length') || 0); if (declared > maxBytes) { try { await response.body?.cancel(); } catch {} throw Object.assign(new Error('Upstream response exceeds configured size limit'), { statusCode: 502, code: 'UPSTREAM_RESPONSE_TOO_LARGE' }); } if (!response.body) return Buffer.alloc(0); const reader = response.body.getReader(), chunks = []; let size = 0; try { while (true) { const { done, value } = await reader.read(); if (done) break; size += value.byteLength; if (size > maxBytes) { await reader.cancel(); throw Object.assign(new Error('Upstream response exceeds configured size limit'), { statusCode: 502, code: 'UPSTREAM_RESPONSE_TOO_LARGE' }); } chunks.push(Buffer.from(value)); } } finally { reader.releaseLock(); } return Buffer.concat(chunks, size); }
async function responseText(response, maxBytes) { return (await responseBuffer(response, maxBytes)).toString('utf8'); }
async function responseJson(response, maxBytes) { const text = await responseText(response, maxBytes); try { return text ? JSON.parse(text) : {}; } catch { throw Object.assign(new Error('Upstream returned invalid JSON'), { statusCode: 502, code: 'UPSTREAM_INVALID_JSON' }); } }
function redactAudit(value, depth = 0) { if (depth > 8) return '[TRUNCATED]'; if (Array.isArray(value)) return value.slice(0, 200).map(v => redactAudit(v, depth + 1)); if (value && typeof value === 'object') { const out = {}; for (const [k, v] of Object.entries(value)) out[k] = /(password|secret|token|authorization|cookie|credential|key)/i.test(k) ? '[REDACTED]' : redactAudit(v, depth + 1); return out; } return typeof value === 'string' ? value.slice(0, 4000) : value; }

function managedIdentityConfig() {
  const modernEndpoint = process.env.IDENTITY_ENDPOINT, modernHeader = process.env.IDENTITY_HEADER;
  const legacyEndpoint = process.env.MSI_ENDPOINT, legacySecret = process.env.MSI_SECRET;
  const endpoint = modernEndpoint || legacyEndpoint, secret = modernEndpoint ? modernHeader : legacySecret;
  if (!endpoint && !secret) return null;
  if (!endpoint || !secret) throw Object.assign(new Error('Managed Identity environment variables are incomplete'), { statusCode: 503, code: 'INVALID_MANAGED_IDENTITY_CONFIGURATION' });
  let u; try { u = new URL(endpoint); } catch { throw Object.assign(new Error('Managed Identity endpoint is invalid'), { statusCode: 503, code: 'INVALID_MANAGED_IDENTITY_CONFIGURATION' }); }
  const host = u.hostname.toLowerCase(), permittedHost = host === '127.0.0.1' || host === '::1' || host === '169.254.169.254';
  const permittedPath = u.pathname === '/msi/token' || u.pathname === '/metadata/identity/oauth2/token';
  if (u.protocol !== 'http:' || u.username || u.password || u.hash || !permittedHost || !permittedPath) throw Object.assign(new Error('Managed Identity endpoint is not an Azure local endpoint'), { statusCode: 503, code: 'INVALID_MANAGED_IDENTITY_CONFIGURATION' });
  return { endpoint: u.toString(), headerName: modernEndpoint ? 'X-IDENTITY-HEADER' : 'Secret', secret };
}

async function graphToken() {
  if (tokenCache.token && Date.now() < tokenCache.expiresAt - 120000) return tokenCache.token;
  let r;
  const identity = managedIdentityConfig();
  if (identity) {
    const u = new URL(identity.endpoint); u.searchParams.set('resource', 'https://graph.microsoft.com'); u.searchParams.set('api-version', '2019-08-01');
    r = await fetchSafe(u, { headers: { [identity.headerName]: identity.secret } });
  } else {
    const tenant = required('ENTRA_TENANT_ID'), client = required('ENTRA_CLIENT_ID'), secret = required('ENTRA_CLIENT_SECRET');
    const form = new URLSearchParams({ client_id: client, client_secret: secret, scope: 'https://graph.microsoft.com/.default', grant_type: 'client_credentials' });
    r = await fetchSafe(`${LOGIN_BASE}/${encodeURIComponent(tenant)}/oauth2/v2.0/token`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form });
  }
  let data = {}; try { data = await responseJson(r, 1024 * 1024); } catch (e) { if (r.ok) throw e; }
  if (!r.ok || !data.access_token) throw Object.assign(new Error('Microsoft Graph authentication failed'), { statusCode: 503, code: 'GRAPH_AUTH_FAILED' });
  tokenCache = { token: data.access_token, expiresAt: Date.now() + Number(data.expires_in || 3600) * 1000 }; return tokenCache.token;
}
async function graph(relative, opt = {}) {
  if (typeof relative !== 'string' || !relative.startsWith('/') || relative.startsWith('//')) throw Object.assign(new Error('Invalid Microsoft Graph relative path'), { statusCode: 500, code: 'GRAPH_PATH_REJECTED' });
  const token = await graphToken();
  const r = await fetchSafe(GRAPH_BASE + relative, { ...opt, headers: { Authorization: `Bearer ${token}`, ...(opt.headers || {}) } });
  if (r.status === 404) return { notFound: true, response: r };
  if (!r.ok) { const upstreamId = r.headers.get('request-id') || r.headers.get('client-request-id') || null; throw Object.assign(new Error(`Microsoft Graph request failed with HTTP ${r.status}${upstreamId ? `; request-id ${upstreamId}` : ''}`), { statusCode: r.status === 412 ? 412 : 502, code: 'GRAPH_REQUEST_FAILED' }); }
  return { response: r };
}
async function targetFolder() {
  if (folderCache && Date.now() - folderCache.cachedAt < 3600000) return folderCache;
  const share = validateUrl('ONEDRIVE_FOLDER_SHARE_URL', required('ONEDRIVE_FOLDER_SHARE_URL'), ONEDRIVE_HOSTS);
  const g = await graph(`/shares/${encodeShareUrl(share)}/driveItem?$select=id,name,webUrl,parentReference`);
  if (g.notFound) throw Object.assign(new Error('Configured OneDrive folder was not found or permission is missing'), { statusCode: 503, code: 'ONEDRIVE_FOLDER_NOT_FOUND' });
  const item = await responseJson(g.response, 1024 * 1024), driveId = item.parentReference?.driveId;
  if (!driveId || !item.id) throw Object.assign(new Error('OneDrive folder identifiers could not be resolved'), { statusCode: 503, code: 'ONEDRIVE_INVALID_RESPONSE' });
  folderCache = { driveId, itemId: item.id, name: item.name, webUrl: item.webUrl, cachedAt: Date.now() }; return folderCache;
}
function fileUrl(folder, name) { return `/drives/${encodeURIComponent(folder.driveId)}/items/${encodeURIComponent(folder.itemId)}:/${encodeURIComponent(name)}:/content`; }
async function readFile(name, maxBytes = MAX_UPSTREAM_RESPONSE_BYTES) { const f = await targetFolder(), g = await graph(fileUrl(f, name)); if (g.notFound) return null; return { text: await responseText(g.response, maxBytes), etag: g.response.headers.get('etag') }; }
async function writeFile(name, text, contentType = 'application/json', ifMatch = null) { const f = await targetFolder(), h = { 'Content-Type': contentType }; if (ifMatch) h['If-Match'] = ifMatch; const g = await graph(fileUrl(f, name), { method: 'PUT', headers: h, body: text }); const item = await responseJson(g.response, 1024 * 1024); return { etag: item.eTag || null, id: item.id, updatedAt: item.lastModifiedDateTime || new Date().toISOString() }; }
async function appendAudit(entry) { const day = new Date().toISOString().slice(0, 10), name = `EnzymeEnterprise-Audit-${day}.ndjson`, old = await readFile(name, MAX_AUDIT_FILE_BYTES); const clean = redactAudit({ ...entry, timestamp: entry.timestamp || new Date().toISOString() }); const next = (old?.text || '') + JSON.stringify(clean) + '\n'; if (Buffer.byteLength(next) > MAX_AUDIT_FILE_BYTES) throw Object.assign(new Error('Monthly audit file reached MAX_AUDIT_FILE_BYTES; archive it under retention policy before continuing'), { statusCode: 507, code: 'AUDIT_FILE_LIMIT_REACHED' }); await writeFile(name, next, 'application/x-ndjson', old?.etag || null); }
function checksum(value) { return crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex'); }
function copilotEndpoint() { if (!isConfigured(process.env.COPILOT_TOKEN_ENDPOINT)) return null; return validateUrl('COPILOT_TOKEN_ENDPOINT', process.env.COPILOT_TOKEN_ENDPOINT, COPILOT_HOSTS); }
function brokerConfigured() { try { return Boolean(copilotEndpoint() || isConfigured(process.env.DIRECT_LINE_SECRET)); } catch { return false; } }
async function copilotToken() {
  const endpoint = copilotEndpoint();
  if (endpoint) { const r = await fetchSafe(endpoint, { headers: { Accept: 'application/json' }, cache: 'no-store' }); let data = {}; try { data = await responseJson(r, 1024 * 1024); } catch (e) { if (r.ok) throw e; } if (!r.ok) throw Object.assign(new Error(`Copilot token endpoint failed with HTTP ${r.status}`), { statusCode: 503, code: 'COPILOT_TOKEN_FAILED' }); return data; }
  const secret = required('DIRECT_LINE_SECRET'), r = await fetchSafe(`${DIRECT_LINE_BASE}/tokens/generate`, { method: 'POST', headers: { Authorization: `Bearer ${secret}`, 'Content-Type': 'application/json' }, body: '{}' }); let data = {}; try { data = await responseJson(r, 1024 * 1024); } catch (e) { if (r.ok) throw e; } if (!r.ok) throw Object.assign(new Error(`Direct Line token generation failed with HTTP ${r.status}`), { statusCode: 503, code: 'DIRECT_LINE_TOKEN_FAILED' }); return data;
}
function configChecks() {
  let oneDrive = 'MISSING', copilot = isConfigured(process.env.DIRECT_LINE_SECRET) ? 'CONFIGURED_DIRECT_LINE' : 'MISSING';
  try { if (isConfigured(process.env.ONEDRIVE_FOLDER_SHARE_URL)) { validateUrl('ONEDRIVE_FOLDER_SHARE_URL', process.env.ONEDRIVE_FOLDER_SHARE_URL, ONEDRIVE_HOSTS); oneDrive = 'CONFIGURED'; } } catch { oneDrive = 'INVALID'; }
  try { if (isConfigured(process.env.COPILOT_TOKEN_ENDPOINT)) { copilotEndpoint(); copilot = 'CONFIGURED_TOKEN_ENDPOINT'; } } catch { copilot = 'INVALID'; }
  const miValues = [process.env.IDENTITY_ENDPOINT, process.env.IDENTITY_HEADER, process.env.MSI_ENDPOINT, process.env.MSI_SECRET].filter(isConfigured);
  let identityStatus = null;
  if (miValues.length) { try { identityStatus = managedIdentityConfig() ? 'MANAGED_IDENTITY' : null; } catch (e) { identityStatus = /incomplete/i.test(e.message) ? 'INCOMPLETE' : 'INVALID'; } }
  const clientValues = [process.env.ENTRA_CLIENT_ID, process.env.ENTRA_CLIENT_SECRET].filter(isConfigured);
  const graphAuth = identityStatus || (clientValues.length === 2 ? 'CLIENT_CREDENTIALS' : clientValues.length ? 'INCOMPLETE' : 'MISSING');
  return { easyAuth: { status: REQUIRE_AUTH ? 'REQUIRED' : (IS_PRODUCTION ? 'DISABLED' : 'LOCAL_TEST') }, entraTenant: { status: EXPECTED_TENANT_ID ? 'CONFIGURED' : 'MISSING', tenantId: EXPECTED_TENANT_ID || null }, graphAuthentication: { status: graphAuth }, oneDriveSetting: { status: oneDrive }, copilotBrokerSetting: { status: copilot }, copilotAgent: { status: 'VERIFIED_METADATA', id: COPILOT_AGENT.id, schemaName: COPILOT_AGENT.schemaName, published: COPILOT_AGENT.componentState === 'Published' } };
}

async function api(req, res, url, id) {
  const p = principal(req);
  if (REQUIRE_AUTH && !p) return fail(res, 401, 'Microsoft Entra authentication required', id);
  if (REQUIRE_AUTH && EXPECTED_TENANT_ID && p.tenantId !== EXPECTED_TENANT_ID) return fail(res, 403, 'Authenticated principal is not from the configured Microsoft Entra tenant', id);
  if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && !mutationAllowed(req)) return fail(res, 403, 'Same-origin mutation marker is required', id);
  if (!rateAllowed(req, url.pathname.includes('/copilot/token') ? 30 : 120)) return fail(res, 429, 'Rate limit exceeded', id, { retryAfterSeconds: 60 });
  if (req.method === 'GET' && url.pathname === '/api/session') return send(res, 200, { authenticated: !!p, user: actor(req), tenantBound: !EXPECTED_TENANT_ID || p?.tenantId === EXPECTED_TENANT_ID, appVersion: APP_VERSION, requestId: id });
  if (req.method === 'GET' && url.pathname === '/api/config') return send(res, 200, { appVersion: APP_VERSION, tenantId: EXPECTED_TENANT_ID, powerPlatformEnvironmentId: POWER_PLATFORM_ENVIRONMENT_ID, dataverseUrl: DATAVERSE_URL, copilot: COPILOT_AGENT, cloud: { provider: 'OneDrive for Business', folderSettingPresent: isConfigured(process.env.ONEDRIVE_FOLDER_SHARE_URL) }, broker: { configured: brokerConfigured(), mode: isConfigured(process.env.COPILOT_TOKEN_ENDPOINT) ? 'Copilot Studio Token Endpoint' : isConfigured(process.env.DIRECT_LINE_SECRET) ? 'Direct Line secret' : 'Not configured' }, requestId: id });
  if (req.method === 'GET' && url.pathname === '/api/readiness') { const checks = configChecks(), ready = checks.easyAuth.status === 'REQUIRED' && ['MANAGED_IDENTITY', 'CLIENT_CREDENTIALS'].includes(checks.graphAuthentication.status) && checks.oneDriveSetting.status === 'CONFIGURED' && !['MISSING', 'INVALID'].includes(checks.copilotBrokerSetting.status); return send(res, ready ? 200 : 503, { status: ready ? 'CONFIGURED' : 'CONFIGURATION_REQUIRED', ready, checks, requestId: id }); }
  if (req.method === 'GET' && url.pathname === '/api/cloud/health') { try { const f = await targetFolder(); return send(res, 200, { status: 'OK', provider: 'OneDrive for Business', folderName: f.name, configured: true, appVersion: APP_VERSION, requestId: id }); } catch (e) { return fail(res, e.statusCode || 503, safeError(e), id, { status: 'NOT_READY', provider: 'OneDrive for Business', configured: false }); } }
  if (req.method === 'GET' && url.pathname === '/api/cloud/state') { const file = await readFile(STATE_FILE); if (!file) return send(res, 200, { state: null, etag: null, updatedAt: null, schemaVersion: '1.0', requestId: id }); let doc; try { doc = JSON.parse(file.text); } catch { throw Object.assign(new Error('Cloud state file contains invalid JSON'), { statusCode: 502, code: 'CLOUD_STATE_INVALID_JSON' }); } const state = doc.state || doc, actual = checksum(state); if (doc.checksum && doc.checksum !== actual) throw Object.assign(new Error('Cloud state checksum validation failed'), { statusCode: 409, code: 'CLOUD_STATE_CHECKSUM_MISMATCH' }); return send(res, 200, { state, etag: file.etag || doc.etag || null, updatedAt: doc.updatedAt || null, schemaVersion: doc.schemaVersion || '1.0', checksum: actual, requestId: id }); }
  if (req.method === 'PUT' && url.pathname === '/api/cloud/state') { const payload = await bodyJson(req); if (!payload.state || typeof payload.state !== 'object' || Array.isArray(payload.state)) return fail(res, 400, 'state object is required', id); const clientEtag = req.headers['if-match'] || null, result = await enqueue(async () => { const previous = await readFile(STATE_FILE); if (previous && !clientEtag) throw Object.assign(new Error('If-Match is required when cloud state already exists'), { statusCode: 428 }); if (clientEtag && (!previous || previous.etag !== clientEtag)) throw Object.assign(new Error('Cloud state changed since the last download'), { statusCode: 412 }); if (previous?.text) { const stamp = `${new Date().toISOString().replace(/[:.]/g, '-')}-${crypto.randomUUID().slice(0, 8)}`; await writeFile(`EnzymeEnterprise-Backup-${stamp}.json`, previous.text); } const updatedAt = new Date().toISOString(), hash = checksum(payload.state), doc = { schemaVersion: String(payload.schemaVersion || '1.0'), appVersion: String(payload.appVersion || APP_VERSION), updatedAt, reason: String(payload.reason || 'state-change').slice(0, 120), checksum: hash, state: payload.state }, saved = await writeFile(STATE_FILE, JSON.stringify(doc, null, 2), 'application/json', clientEtag); await appendAudit({ type: 'STATE_SAVED', actor: actor(req), appVersion: doc.appVersion, reason: doc.reason, checksum: hash, requestId: id }); return { ...saved, updatedAt, checksum: hash }; }); return send(res, 200, { status: 'SAVED', ...result, requestId: id }); }
  if (req.method === 'POST' && url.pathname === '/api/cloud/audit') { const event = await bodyJson(req); if (Buffer.byteLength(JSON.stringify(event)) > MAX_AUDIT_BYTES) return fail(res, 413, 'Audit event exceeds 64 KB', id); await enqueue(() => appendAudit({ type: 'CLIENT_EVENT', actor: actor(req), event, requestId: id })); return send(res, 201, { status: 'RECORDED', requestId: id }); }
  if (req.method === 'POST' && url.pathname === '/api/cloud/backup') { const result = await enqueue(async () => { const current = await readFile(STATE_FILE); if (!current) throw Object.assign(new Error('No cloud state exists'), { statusCode: 404 }); const stamp = `${new Date().toISOString().replace(/[:.]/g, '-')}-${crypto.randomUUID().slice(0, 8)}`, saved = await writeFile(`EnzymeEnterprise-Backup-${stamp}.json`, current.text); await appendAudit({ type: 'BACKUP_CREATED', actor: actor(req), requestId: id }); return saved; }); return send(res, 201, { status: 'BACKUP_CREATED', ...result, requestId: id }); }
  if (req.method === 'GET' && url.pathname === '/api/health') { let cloud = false, cloudError = null; try { await targetFolder(); cloud = true; } catch (e) { cloudError = safeError(e); } const broker = brokerConfigured(), checks = { ...configChecks(), copilotBroker: { status: broker ? 'CONFIGURED' : 'MISSING' }, oneDrive: { status: cloud ? 'CONNECTED' : 'NOT_READY', error: cloudError } }; return send(res, 200, { status: broker && cloud ? 'OK' : 'CONFIGURATION_REQUIRED', ready: broker && cloud, appVersion: APP_VERSION, copilotTokenBroker: broker, oneDriveConfigured: cloud, cloudError, checks, requestId: id }); }
  if (req.method === 'POST' && url.pathname === '/api/copilot/token') return send(res, 200, { ...(await copilotToken()), requestId: id });
  if (req.method === 'POST' && url.pathname === '/api/copilot/token/refresh') { const data = await bodyJson(req), token = data.token; if (!token) return fail(res, 400, 'token required', id); const r = await fetchSafe(`${DIRECT_LINE_BASE}/tokens/refresh`, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: '{}' }); let out = {}; try { out = await responseJson(r, 1024 * 1024); } catch (e) { if (r.ok) throw e; } if (!r.ok) throw Object.assign(new Error(`Direct Line token refresh failed with HTTP ${r.status}`), { statusCode: 503, code: 'DIRECT_LINE_REFRESH_FAILED' }); return send(res, 200, { ...out, requestId: id }); }
  if (req.method === 'GET' && url.pathname === '/api/copilot/verify') { const started = Date.now(), data = await copilotToken(); return send(res, 200, { verified: !!(data.token || data.accessToken || data.access_token), source: isConfigured(process.env.COPILOT_TOKEN_ENDPOINT) ? 'token endpoint' : 'Direct Line broker', latencyMs: Date.now() - started, requestId: id }); }
  return fail(res, 404, 'API route not found', id);
}
function contentType(file) { return ({ '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' })[path.extname(file).toLowerCase()] || 'application/octet-stream'; }
function staticFile(req, res, url, id) { if (!['GET', 'HEAD'].includes(req.method)) return fail(res, 405, 'Method not allowed', id); let rel; try { rel = decodeURIComponent(url.pathname); } catch { return fail(res, 400, 'Invalid URL encoding', id); } if (rel === '/' || !path.extname(rel)) rel = '/index.html'; const file = path.resolve(PUBLIC, '.' + rel); if (!file.startsWith(PUBLIC + path.sep)) return fail(res, 403, 'Forbidden path', id); fs.stat(file, (err, stat) => { if (err || !stat.isFile()) return fail(res, 404, 'File not found', id); const etag = `"${stat.size.toString(16)}-${Math.floor(stat.mtimeMs).toString(16)}"`; if (req.headers['if-none-match'] === etag) { res.writeHead(304, headers({ ETag: etag })); return res.end(); } res.writeHead(200, headers({ 'Content-Type': contentType(file), 'Content-Length': stat.size, ETag: etag, 'Cache-Control': rel === '/index.html' ? 'no-cache' : 'public, max-age=300' })); if (req.method === 'HEAD') return res.end(); fs.createReadStream(file).pipe(res); }); }
const server = http.createServer(async (req, res) => { const id = requestId(req); res.setHeader('X-Request-ID', id); try { const url = new URL(req.url, 'http://localhost'); if (url.pathname.startsWith('/api/')) await api(req, res, url, id); else staticFile(req, res, url, id); } catch (e) { const code = e?.code ? String(e.code).replace(/[^A-Z0-9_-]/gi, '').slice(0, 40) : undefined; fail(res, e.statusCode || 500, safeError(e), id, { ...(code ? { code } : {}), conflict: e.statusCode === 412 }); } });
server.requestTimeout = 30000; server.headersTimeout = 35000; server.keepAliveTimeout = 5000;
server.listen(PORT, () => console.log(`Enzyme Enterprise v${APP_VERSION} listening on ${PORT}`));
function shutdown() { server.close(() => process.exit(0)); setTimeout(() => process.exit(1), 10000).unref(); }
process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);
