'use strict';
const IS_PRODUCTION = (process.env.NODE_ENV || '').toLowerCase() === 'production';
const MIN_NODE_MAJOR = 20;
const ALLOWED_MI_HOSTS = new Set(['127.0.0.1', '::1', '169.254.169.254']);
const ALLOWED_MI_PATHS = new Set(['/msi/token', '/metadata/identity/oauth2/token']);
const ONEDRIVE_HOSTS = ['.sharepoint.com', '.my.sharepoint.com', '1drv.ms'];
const COPILOT_HOSTS = ['.environment.api.powerplatform.com', '.api.powerplatform.com', '.botframework.com'];
const placeholder = /^(?:replace|todo|changeme|your[-_]|https:\/\/your|secret$)/i;
const configured = v => typeof v === 'string' && v.trim().length > 0 && !placeholder.test(v.trim());
function allowedHost(host, list) { host = host.toLowerCase(); return list.some(x => x.startsWith('.') ? host.endsWith(x) && host.length > x.length : host === x); }
function validateHttps(name, value, hosts) {
  if (!configured(value)) return { status: 'MISSING', detail: 'missing' };
  try { const u = new URL(value); if (IS_PRODUCTION && u.protocol !== 'https:') throw new Error('HTTPS is required'); if (!allowedHost(u.hostname, hosts)) throw new Error('non-allow-listed endpoint'); if (u.username || u.password || u.hash) throw new Error('credentials or fragments are not allowed'); return { status: 'PASS', detail: u.hostname }; }
  catch (e) { return { status: 'BLOCKED', detail: `${name}: ${e.message}` }; }
}
function managedIdentityStatus() {
  const modern = [process.env.IDENTITY_ENDPOINT, process.env.IDENTITY_HEADER];
  const legacy = [process.env.MSI_ENDPOINT, process.env.MSI_SECRET];
  const any = [...modern, ...legacy].some(configured);
  if (!any) return null;
  const pair = modern.some(configured) ? modern : legacy;
  if (!pair.every(configured)) return { status: 'INCOMPLETE', detail: 'Managed Identity endpoint/header pair is incomplete' };
  try { const u = new URL(pair[0]); if (u.protocol !== 'http:' || u.username || u.password || u.hash || !ALLOWED_MI_HOSTS.has(u.hostname.toLowerCase()) || !ALLOWED_MI_PATHS.has(u.pathname)) throw new Error('endpoint is not an Azure local Managed Identity endpoint'); return { status: 'MANAGED_IDENTITY', detail: modern.some(configured) ? 'Modern App Service identity endpoint' : 'Legacy MSI endpoint' }; }
  catch (e) { return { status: 'INVALID', detail: e.message }; }
}
function graphAuthStatus() {
  const mi = managedIdentityStatus(); if (mi) return mi;
  const pair = [process.env.ENTRA_CLIENT_ID, process.env.ENTRA_CLIENT_SECRET], count = pair.filter(configured).length;
  return count === 2 ? { status: 'CLIENT_CREDENTIALS', detail: 'Client credentials' } : count ? { status: 'INCOMPLETE', detail: 'Client credential pair is incomplete' } : { status: 'MISSING', detail: 'No Graph authentication configured' };
}
function row(name, ok, value) { return { name, status: ok ? 'PASS' : 'BLOCKED', value }; }
const checks = [];
const major = Number(process.versions.node.split('.')[0]); checks.push(row('NODE_VERSION', major >= MIN_NODE_MAJOR, process.versions.node));
checks.push(row('NODE_ENV', IS_PRODUCTION, process.env.NODE_ENV || 'missing'));
checks.push(row('REQUIRE_EASY_AUTH', process.env.REQUIRE_EASY_AUTH === 'true', process.env.REQUIRE_EASY_AUTH || 'missing'));
checks.push(row('EXPECTED_ENTRA_TENANT_ID', configured(process.env.EXPECTED_ENTRA_TENANT_ID), process.env.EXPECTED_ENTRA_TENANT_ID || 'missing'));
const graph = graphAuthStatus(); checks.push(row('GRAPH_AUTH', ['MANAGED_IDENTITY','CLIENT_CREDENTIALS'].includes(graph.status), `${graph.status}: ${graph.detail}`));
const od = validateHttps('ONEDRIVE_FOLDER_SHARE_URL', process.env.ONEDRIVE_FOLDER_SHARE_URL, ONEDRIVE_HOSTS); checks.push(row('ONEDRIVE_FOLDER_SHARE_URL', od.status === 'PASS', od.detail));
let cp = configured(process.env.DIRECT_LINE_SECRET) ? { status: 'PASS', detail: 'Protected Direct Line setting present' } : validateHttps('COPILOT_TOKEN_ENDPOINT', process.env.COPILOT_TOKEN_ENDPOINT, COPILOT_HOSTS); checks.push(row('COPILOT_BROKER', cp.status === 'PASS', cp.detail));
const upstream = Number(process.env.MAX_UPSTREAM_RESPONSE_BYTES || 16777216), audit = Number(process.env.MAX_AUDIT_FILE_BYTES || 67108864);
checks.push(row('MAX_UPSTREAM_RESPONSE_BYTES', Number.isSafeInteger(upstream) && upstream >= 1024 && upstream <= 134217728, upstream));
checks.push(row('MAX_AUDIT_FILE_BYTES', Number.isSafeInteger(audit) && audit >= upstream && audit <= 268435456, audit));
const ready = checks.every(x => x.status === 'PASS');
console.log(JSON.stringify({ appVersion: '2.3.0', ready, checks }, null, 2));
process.exitCode = ready ? 0 : 2;
