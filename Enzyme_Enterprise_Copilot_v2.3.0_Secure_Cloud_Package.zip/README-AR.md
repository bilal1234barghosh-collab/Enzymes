# Enzyme Enterprise Copilot v2.3.0 — الحزمة المؤسسية المحسّنة والمربوطة ببيانات الوكيل المؤكدة

## النتيجة
هذه الحزمة تحافظ على محرك الجرعات الأصلي دون استبداله، وتضيف طبقة تشغيل سحابية آمنة وقابلة للتتبع. يعمل الخادم على Node.js 20 أو أحدث **دون أي حزم خارجية**؛ لذلك لا يلزم `npm install`.

## البيانات المؤكدة والمدخلة مسبقًا
- Tenant ID: `cd11d182-105e-4331-a55d-6e2db544ee3f`
- Power Platform environment: `Default-cd11d182-105e-4331-a55d-6e2db544ee3f`
- Dataverse: `https://orgd66b8caf.crm4.dynamics.com/`
- Copilot Agent GUID: `91ac31d0-af7f-4a75-b82c-af78ceb3e6b3`
- Schema name: `cr1c6_enzymeenterprisecopilot_zgMsug`
- الاسم: `Enzyme Enterprise Copilot`
- الحالة المؤكدة: `Active`، `Provisioned`، `Published`
- النشر: `2026-09-19T00:14:30Z`
- المصادقة: `Integrated`، والتشغيل `Always`

هذه قيم تعريفية غير سرية. لا يغني Agent GUID أو Canvas URL عن Copilot Token Endpoint أو Direct Line secret.

## التحسينات الشاملة
- تصحيح فصل Agent GUID الحقيقي عن Schema name وعرضهما بدقة في الواجهة.
- ربط صريح بالمستأجر المتوقع ورفض هوية Entra القادمة من مستأجر مختلف.
- حماية إضافية لعمليات الكتابة وطلب الرموز عبر علامة Same-Origin مضادة لطلبات CSRF.
- نقطة `/api/config` لعرض الإعدادات غير السرية فقط، و`/api/readiness` لفحص اكتمال الإعداد دون استدعاء الخدمات، و`/api/health` للتحقق الحي من OneDrive.
- نقطة `/api/copilot/verify` للتحقق الحي من أن وسيط Copilot يعيد رمزًا صالحًا دون كشف الرمز.
- اتصال Copilot تلقائي بعد تسجيل الدخول عبر Same-Origin Token Broker.
- قوائم سماح مستقلة لمضيفي Graph وMicrosoft login وDirect Line وCopilot وOneDrive، مع رفض credentials وfragments وHTTP والعناوين المحلية/الخاصة في production.
- تنقية متكررة لبيانات سجل التدقيق وحد أقصى `64 KB` لكل حدث.
- حد افتراضي لاستجابة Upstream قدره `16777216` بايت (`16 MB`) مع قراءة streaming محدودة؛ والنطاق المقبول من `1024` إلى `134217728` بايت.
- حد افتراضي لملف Audit اليومي قدره `67108864` بايت (`64 MB`) وبحد أقصى `268435456` بايت؛ عند بلوغه يعيد الخادم HTTP `507` والكود `AUDIT_FILE_LIMIT_REACHED` دون حذف السجل السابق.
- OneDrive for Business هو مصدر الحالة عند التشغيل المستضاف، مع Local Cache عند انقطاع الشبكة.
- مزامنة مؤجلة تلقائيًا بعد عودة الاتصال.
- ETag وHTTP 412 لمنع الكتابة فوق تحديث أحدث.
- تسلسل جميع الكتابات السحابية لمنع السباقات.
- نسخة احتياطية قبل كل تحديث للحالة.
- تحقق SHA-256 من سلامة الحالة عند القراءة، مع `CLOUD_STATE_INVALID_JSON` و`CLOUD_STATE_CHECKSUM_MISMATCH` والحفاظ على الملف الأصلي عند الفشل.
- سجل تدقيق يومي `EnzymeEnterprise-Audit-YYYY-MM-DD.ndjson` يتضمن المستخدم المؤسسي وRequest ID.
- دعم Microsoft Entra/App Service Authentication.
- دعم Azure Managed Identity الحديث (`IDENTITY_ENDPOINT` و`IDENTITY_HEADER`) والقديم (`MSI_ENDPOINT` و`MSI_SECRET`) مع تحقق مخصص للـendpoint المحلي الذي تحقنه Azure، وClient Credentials كخيار احتياطي فقط.
- حدود لحجم الطلب `12 MB`، وحد للطلبات، ومهلات وإعادة محاولة محسوبة لخدمات Microsoft.
- رؤوس أمان تشمل CSP وnosniff وSAMEORIGIN وPermissions Policy وHSTS في production و`Cross-Origin-Resource-Policy: same-origin`.
- أكواد خطأ منظمة وآمنة في JSON مع `X-Request-ID`، وإخفاء الأسرار من رسائل الخطأ وعدم إرسال Graph/Copilot credentials إلى المتصفح.
- إيقاف سلس للخادم، ETag للملفات الثابتة، وعدم وجود تبعيات npm.

## شرط الاتصال الدائم
فتح `public/index.html` بصيغة `file://` يشغّل المحرك محليًا، لكنه لا يوفر اتصالًا دائمًا وآمنًا. الاتصال التلقائي الدائم يبدأ بعد نشر الحزمة على HTTPS وإضافة الإعدادات المحمية مرة واحدة.

الحزمة لا تحتوي أي سر مصطنع أو مضمّن. يلزم فعليًا مورد Azure متاح وهوية Managed Identity بصلاحية Graph، ثم إضافة رابط مجلد OneDrive وCopilot Token Endpoint كإعدادات خادم محمية. لا يمكن تعويض هذه الموارد ببيانات افتراضية.

## موانع الجاهزية الحية عند إعداد هذه الحزمة
- اشتراكات Azure المتاحة للحساب الحالي: `0`؛ لذلك لم يُنشأ Resource Group أو App Service ولم يُنفذ نشر حي.
- لم يتوفر `ONEDRIVE_FOLDER_SHARE_URL`، كما تعذر إثبات Graph/OneDrive حيًا بسبب غياب خطة الخدمة `M365_COPILOT_BUSINESS_CHAT` في الاتصال المستخدم.
- لم يتوفر `COPILOT_TOKEN_ENDPOINT` أو `DIRECT_LINE_SECRET`؛ ومحاولة تشغيل الوكيل مباشرة أعادت HTTP `404`، ولذلك لم يُثبت مسار Copilot end-to-end.
- هذه الموانع لا تغيّر محرك الجرعات أو النموذج أو المعايرة. بعد توفير الموارد، شغّل `node preflight.js` ثم نفّذ فحوص `/api/readiness` و`/api/health` و`/api/copilot/verify`.

## النشر على Azure App Service
تتضمن الحزمة قالب `infra/main.bicep`، مثال parameters بلا أسرار، سكربت `infra/deploy.sh`، ودليل `infra/RUNBOOK-AR.md`. تبقى Subscription وResource Group واسم Web App وEntra Client ID والقيم المحمية معلمات إلزامية؛ لا توجد قيم مصطنعة.

1. جهّز Azure Subscription وResource Group وEntra App Registration في المستأجر المؤكد.
2. مرر القيم المطلوبة إلى `infra/deploy.sh` عبر جلسة آمنة؛ ينشئ القالب Linux App Service بـNode.js 20 وSystem-Assigned Managed Identity وHTTPS وEasy Auth.
3. انشر تطبيق ZIP واضبط أمر التشغيل على `node server.js`.
4. فعّل Managed Identity للتطبيق وامنحها أقل صلاحية تطبيق Microsoft Graph تكفي للمجلد/الموقع المحدد، مع موافقة مسؤول المستأجر. فضّل صلاحية موقع محدد مثل `Sites.Selected` عندما يلائم تصميم SharePoint؛ إن لم يدعم مسار `/shares` ذلك في المستأجر، استخدم معرّفات Site/Drive ثابتة أو صلاحية Graph المناسبة بعد مراجعة أمنية. استخدم Client Secret فقط إذا تعذر Managed Identity.
5. أضف إعدادات `.env.example` من App Service > Environment variables. لا توسع قوائم المضيفين المسموحين دون مراجعة، ولا تضع أسرارًا داخل HTML أو المستودع.
6. ضع رابط المجلد في `ONEDRIVE_FOLDER_SHARE_URL` كإعداد خادم محمي.
7. ضع Copilot Studio Token Endpoint في `COPILOT_TOKEN_ENDPOINT`، أو استخدم `DIRECT_LINE_SECRET` كبديل.
8. أعد تشغيل App Service.

## التحقق بعد النشر
- `GET /api/session`: يؤكد هوية Entra الحالية وتطابق المستأجر.
- `GET /api/config`: يعرض معرّفات البيئة والوكيل المؤكدة دون أي أسرار.
- `GET /api/readiness`: يجب أن يعيد HTTP `200` و`ready: true` بعد اكتمال الإعدادات.
- `GET /api/health`: يعيد `OK` فقط عند إعداد وسيط Copilot واتصال OneDrive؛ وإلا يعيد `CONFIGURATION_REQUIRED` مع فحوص مفصلة.
- `GET /api/cloud/health`: يجب أن يعيد `status: OK`.
- `POST /api/copilot/token` و`GET /api/copilot/verify`: يجب استدعاؤهما داخل جلسة Entra المصادق عليها؛ لا تسجل قيمة الرمز في السجلات.
- داخل البرنامج: نفّذ «فحص التكامل» وتأكد من ظهور OneDrive Cloud = `CONNECTED`.
- نفّذ تعديلًا غير حساس، ثم تحقق من إنشاء:
  - `EnzymeEnterprise-State.json`
  - `EnzymeEnterprise-Backup-<timestamp>-<uuid8>.json` بعد التحديث التالي.
  - `EnzymeEnterprise-Audit-YYYY-MM-DD.ndjson`

## الاختبارات
- `npm run check`: فحص بناء JavaScript.
- `npm test`: يشغّل `31` فحصًا ثابتًا، و`25` فحص تكامل Graph/Copilot، و`6` فحوص للمصادقة وربط المستأجر وحماية Same-Origin، و`15` فحص أمن وSSRF وManaged Identity والحدود والرؤوس، و`13` فحص تعافٍ وسلامة وحماية Audit.
- `npm run preflight`: فحص نشر production؛ يعيد exit code `2` إذا بقي إعداد أو سر محمي أو اتصال مطلوب غير متاح.

## الحوكمة
- Prediction لا يتحول تلقائيًا إلى Actual Outcome أو Validated Outcome.
- اعتماد نتائج فعلية، المعايرة، التدريب، وترقية نموذج جديد تبقى خاضعة للمراجعة والصلاحية.
- لا تُرفع حسابات المستخدمين المحلية أو تجزئات كلمات المرور أو كائنات النماذج الحية إلى OneDrive.
- لا يُحذف أي سجل أو Backup تلقائيًا.
- أرشفة Audit والرجوع موثقان في `infra/RUNBOOK-AR.md` وفق Preserve → Version → Archive → Correct → Rollback.
- لا تُعد الحزمة منشورة أو متصلة حيًا قبل أن تصبح نتيجة Production Preflight هي `ready: true` وتنجح فحوص Easy Auth وGraph read/write وETag وBackup وAudit وCopilot وCloud Sync.
